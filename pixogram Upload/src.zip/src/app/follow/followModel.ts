import { User } from '../user/userModel';

export class Follow
{
    id:number;
    userid:User;
    followid:User;
}