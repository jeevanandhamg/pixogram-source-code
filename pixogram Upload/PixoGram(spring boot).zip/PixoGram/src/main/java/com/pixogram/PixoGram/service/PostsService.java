package com.pixogram.PixoGram.service;



import com.pixogram.PixoGram.model.Posts;


public interface PostsService {

	void upload(Posts post);

}
