package com.pixogram.PixoGram.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pixogram.PixoGram.model.Block;

public interface BlockRepository extends JpaRepository<Block, Long> {

}
