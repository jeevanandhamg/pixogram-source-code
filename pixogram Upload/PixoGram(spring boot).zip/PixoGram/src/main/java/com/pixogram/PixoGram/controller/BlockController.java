package com.pixogram.PixoGram.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.pixogram.PixoGram.service.BlockService;

public class BlockController {

	@Autowired
	BlockService service;
	
}
